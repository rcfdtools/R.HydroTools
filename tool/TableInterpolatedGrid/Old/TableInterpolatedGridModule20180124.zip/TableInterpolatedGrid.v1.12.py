# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# TablaInterpolarPhyton_v1_12.py
# Created on: 2017-12-20
# Created by: r.cfdtools@gmail.com
# 
# Tested with: ArcGis 10.5 and Python 2.7.12
#
# Description: Using a R Weather CDMS App tables, let build interpolate
# grids maps in a tiff format for daily or monthly values. With the generate
# tiff maps user can make a video for to study a weather parameter on the time.
#
# Table format file input valid: dBase file .dbf or comma separated values .csv
# Float or doubles values required dot as decimal separator)
#
# Requirements:
#   csv file need header row.
#   Decimal values always been separated using dot.
#   Field values can´t content text with comma. Ex: Filter year, month, day.
#   Header row minimun required: Julian, Month, CX, CX, CZ, VAR.
# 
# Example tables:
#	R_TableBaseExample3.csv (Total Monthly Rain)
#	R_TableBaseExample4.csv (Total Daily Rain)
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy
import os
import os.path
import shutil
import time
import warnings
import R_TableToGridArcGisModule
warnings.filterwarnings("ignore")

# Local variables:
vFolderMain = "D:\\R_Python\\TableToGridArcGis\\"
vFolderOutput = vFolderMain+"Out\\"
vFolderOutputColorMap = vFolderMain+"OutColorMap\\"
vFolderTemp = vFolderMain+"Temp\\"
vFileName = vFolderMain+"R_TableBaseExample2.csv"
vShapeFile = vFolderTemp+"R_shapefile.shp"
vFolderColorMapStyle = vFolderMain+"ColorMapStyle\\"
vTimeStart = time.time()
vNumColor = 256 # Always use the total color less 1. Example: for 256 colors use 255 values (0 to 255)

# Welcome & Info screen
print ""
print "-----------------------------------------------------------------------------------------"
print " CREATE WEATHER PARAMETER GRID SETS USING dBASE TABLE v1.12"
print " by r.cfdtools@gmail.com Python: 2.7.12. ArcGIS: 10.5"
print "-----------------------------------------------------------------------------------------"
print R_TableToGridArcGisModule.fRPrompt(),"Alert - Close ARCGIS applications before start"
print R_TableToGridArcGisModule.fRPrompt(),"Processing file",vFileName
vFields=R_TableToGridArcGisModule.fCSVTotalFieldFound(vFileName)
vRowTotal = R_TableToGridArcGisModule.fCSVTotalRecordFound(vFileName)
R_TableToGridArcGisModule.fCSVPreviewRecord(vFileName,vRowTotal)
vFieldNumberEval=R_TableToGridArcGisModule.fCSVHeader(vFileName,vRowTotal,vFields)
vFieldEvalStr = vFieldNumberEval[1]
R_TableToGridArcGisModule.fCSVStatistic(vFileName,vRowTotal,vFieldNumberEval[0])
try:
    vDailyOrMonthly = int(input("%s Input (1) for *DAILY or (2) for MONTHLY data type (* Default) >> " %(R_TableToGridArcGisModule.fRPrompt())))
    if vDailyOrMonthly != 1 and vDailyOrMonthly != 2:
        vDailyOrMonthly = 1
        print R_TableToGridArcGisModule.fRPrompt(),"Alert - Data type daily or monthly invalid, system use (1) Daily as default..."
except:
    vDailyOrMonthly = 1
    print R_TableToGridArcGisModule.fRPrompt(),"Alert - Data type daily or monthly no specified, system use (1) Daily as default..."
try:
    vNumGrid = int(input("%s Total Grids to create (1-12 for monthly or 1-365 for daily values) >> " %(R_TableToGridArcGisModule.fRPrompt())))
except:
    vNumGrid = 1
    print R_TableToGridArcGisModule.fRPrompt(),"Alert - Number of grids do not enter, system create only 1 grid..."
try:
    vResGrid = int(input("%s Grid Resolution in meters (default 1000m) >> " %(R_TableToGridArcGisModule.fRPrompt())))
except:
    vResGrid = 1000
    print R_TableToGridArcGisModule.fRPrompt(),"Alert - Grid resolution do not enter, system use 1000 meters by default..."
vColorMapFileArray = R_TableToGridArcGisModule.fColorMapStyle(vFolderColorMapStyle)
vColorMapFile = vColorMapFileArray[0]
vColorMapFilePrev = vColorMapFileArray[1]
os.system(vColorMapFilePrev)

# Delete previous data Temp and Out folder created
try:
    shutil.rmtree(vFolderOutput) #Remove Out folder
except:
    print R_TableToGridArcGisModule.fRPrompt(),"Out folder doesn't exists"
os.mkdir(vFolderOutput) #Create empty Out folder
try:
    shutil.rmtree(vFolderOutputColorMap) #Remove Temp folder
except:
    print R_TableToGridArcGisModule.fRPrompt(),"Out Color Map folder doesn't exists"
os.mkdir(vFolderOutputColorMap) #Create empty Temp folder
try:
    shutil.rmtree(vFolderTemp) #Remove Temp folder
except:
    print R_TableToGridArcGisModule.fRPrompt(),"Temp folder doesn't exists"
os.mkdir(vFolderTemp) #Create empty Temp folder

# Grid builder section
vNumGridStr = str(vNumGrid)
vInc=1; vMaxPixelValue = -9999; vDayMonthMax = 0;
print "\n\t-----------------------------------------------------------------------------------------"
print "\tSTARTING", vNumGridStr, "GRIDS CREATION FILES"
print "\t-----------------------------------------------------------------------------------------"
while vInc <= vNumGrid:
    vIncStr = str(vInc)

    # Process: Make XY Event Layer
    vEventLyr = "EventLyr" + vIncStr
    arcpy.MakeXYEventLayer_management(vFileName, "CX", "CY", vEventLyr, "PROJCS['GAUSS_BTA_MAGNA',GEOGCS['CGS_SIRGAS',DATUM['CGS_SIRGAS',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Transverse_Mercator'],PARAMETER['False_Easting',1000000.0],PARAMETER['False_Northing',1000000.0],PARAMETER['Central_Meridian',-74.077507917],PARAMETER['Scale_Factor',1.0],PARAMETER['Latitude_Of_Origin',4.596200417],UNIT['Meter',1.0]];-4623200 -9510300 10000;-100000 10000;-100000 10000;0.001;0.001;0.001;IsHighPrecision", "CZ")

    # Process: Select records from Julian day number
    if vDailyOrMonthly == 1:
        arcpy.Select_analysis(vEventLyr, vShapeFile, "\"Julian\" =" + vIncStr)
        #print "\tdaily"
    else:
        arcpy.Select_analysis(vEventLyr, vShapeFile, "\"Month\" =" + vIncStr)
        #print "\tmonthly"

    # Process: IDW - Inverse Dinstance Weight Intepolation
    vGRDayNFileName = "GRDM" + vIncStr.zfill(3) + ".tif"
    vGRDayNTif = vFolderOutput + vGRDayNFileName
    #arcpy.gp.Idw_sa(vShapeFile, "Var", vGRDayNTif, vResGrid, "2", "VARIABLE 12", "")
    arcpy.gp.Idw_sa(vShapeFile, vFieldEvalStr, vGRDayNTif, vResGrid, "2", "VARIABLE 12", "")
    
    # Remove and create Temp folder
    shutil.rmtree(vFolderTemp) #Remove Temp folder
    os.mkdir(vFolderTemp) #Create empty Temp folder

    # Process: Show created raster properties
    vCYMax = arcpy.GetRasterProperties_management(vGRDayNTif, "TOP", "")
    vCYMaxAux = float (vCYMax.getOutput(0))
    vCYMin = arcpy.GetRasterProperties_management(vGRDayNTif, "BOTTOM", "")
    vCYMinAux = float (vCYMin.getOutput(0))
    vYSize = (vCYMaxAux - vCYMinAux) / 1000
    vCXMax = arcpy.GetRasterProperties_management(vGRDayNTif, "RIGHT", "")
    vCXMaxAux = float (vCXMax.getOutput(0))
    vCXMin = arcpy.GetRasterProperties_management(vGRDayNTif, "LEFT", "")
    vCXMinAux = float (vCXMin.getOutput(0))
    vXSize = (vCXMaxAux - vCXMinAux) / 1000
    vValMax = arcpy.GetRasterProperties_management(vGRDayNTif, "MAXIMUM", "")
    vValMaxAux = float (vValMax.getOutput(0))
    print "\tFile", vGRDayNFileName, "- High(km):",vYSize,"- Width(km):",vXSize,"- Maximum:",round(vValMaxAux,4),"- successful..."
    if vValMaxAux > vMaxPixelValue:
        vMaxPixelValue = vValMaxAux
        vDayMonthMax = vInc
    vInc += 1


# Grid color map using integer scale
vInc=1; vMaxPixelValueStr = str(vMaxPixelValue); vNumColorStr = str(vNumColor);
print "\n\t-----------------------------------------------------------------------------------------"
print "\tSTARTING", vNumGridStr, "GRIDS COLOR SCALED CREATION FILES"
print "\t-----------------------------------------------------------------------------------------"
while vInc <= vNumGrid:
    vIncStr = str(vInc)
    vGRDayNFileName = "GRDM" + vIncStr.zfill(3) + ".tif"
    vGRDayNTifSorce = vFolderOutput + vGRDayNFileName
    vGRDayNTifTarget = vFolderOutputColorMap + vGRDayNFileName
    vAlgebraMapClc = "Int ((\""+vGRDayNTifSorce+"\" *"+vNumColorStr+") / "+vMaxPixelValueStr+")"
    arcpy.gp.RasterCalculator_sa(vAlgebraMapClc, vGRDayNTifTarget)
    print "\tFile Color Map", vGRDayNFileName,"successful..."
    arcpy.AddColormap_management(vGRDayNTifTarget, "", vColorMapFile)
    vInc += 1

# Show final process information
vTimeEnd = time.time()
print "\n\t-----------------------------------------------------------------------------------------"
print "\tSTATISTICS AND RESUME REPORT"
print "\t-----------------------------------------------------------------------------------------"
print "\tGrids created on                ", vFolderOutput
print "\tColor Map Grids created on      ", vFolderOutputColorMap
print "\tMaximun pixel value all grids)  ", round(vMaxPixelValue,4)
print "\tDay or Month with maximum value ", vDayMonthMax
print "\tProcess Acomplished              (dt = ", round(vTimeEnd - vTimeStart,1) , "sec(s) or" , round((vTimeEnd - vTimeStart)/60,1) , "min(s))"

try:
    vExit = input("\n%s Press Enter to Exit" %(R_TableToGridArcGisModule.fRPrompt()))
except:
    vExit = "y"
