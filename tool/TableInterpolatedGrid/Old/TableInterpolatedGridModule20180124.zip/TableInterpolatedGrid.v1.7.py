# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# TablaInterpolarPhyton_v1_0.py
# Created on: 2017-11-30 18:35:02.00000
# 
# Description: r.cfdtools@gmail.com Tested in ArcGis 10.5 with Python 2.7.12
# Using a R Weather CDMS App tables, create interpolate grids maps in a
# tiff format for everyday or every month. With the generate tiff maps
# user can make a video for to follow or study the weather parameter.
# 
# REFERENCES:
#   http://www.mclibre.org/consultar/python/index.html
#   http://librosweb.es/libro/algoritmos_python/capitulo_12/excepciones.html
#   https://sourceforge.net/projects/dbfpy/files/dbfpy/2.3.1/
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy
import os
import os.path
import shutil
import time

# Local variables:
R_OutputFolder = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\Out\\"
R_OutputFolderColorMap = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\OutColorMap\\"
R_TempFolder = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\Temp\\"
R_TableBase = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\R_TableBaseExample2.dbf"
R_ShapeFile = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\Temp\\R_shapefile.shp"
R_ColorMapFile = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\ColorMapStyle\\ColorMapArcGIS_v8.clr"
vTimeStart = time.time()
vNumColors = 255

# Welcome & Info screen
print ""
print "-----------------------------------------------------------------------------------------"
print "R: CREATE WEATHER PARAMETER GRID SETS USING dBASE TABLE"
print "R: by r.cfdtools@gmail.com"
print "-----------------------------------------------------------------------------------------"
print "R: Alert - Close ARCGIS applications before start"
try:
    numGrids = int(input("R: Total Grids to create (12 for monthly or 365 for daily values) >> "))
except:
    numGrids = 1
    print "R: Alert - Number of grids do not enter, system create only one grid."
try:
    resGrids = int(input("R: Grid Resolution in meters (defaul 1000m) >> "))
except:
    resGrids = 1000
    print "R: Alert - Grid resolution do not enter, system use 1000 meters by default."
print "-----------------------------------------------------------------------------------------"
print ""


# Delete previous data Temp and Out folder created
try:
    shutil.rmtree(R_OutputFolder) #Remove Out folder
except:
    print "R: Out folder doesn't exists"
os.mkdir(R_OutputFolder) #Create empty Out folder
try:
    shutil.rmtree(R_OutputFolderColorMap) #Remove Temp folder
except:
    print "R: Out Color Map folder doesn't exists"
os.mkdir(R_OutputFolderColorMap) #Create empty Temp folder
try:
    shutil.rmtree(R_TempFolder) #Remove Temp folder
except:
    print "R: Temp folder doesn't exists"
os.mkdir(R_TempFolder) #Create empty Temp folder

# Grid builder section
numGrids_str = str(numGrids)
i=1; maxPixelValue = -9999; dayMonthMax = 0;
print "R: Starting", numGrids_str, "Grids creation files"
while i <= numGrids:
    i_str = str(i)

    # Process: Make XY Event Layer
    R_EventLyr = "EventLyr" + i_str
    arcpy.MakeXYEventLayer_management(R_TableBase, "CX", "CY", R_EventLyr, "PROJCS['GAUSS_BTA_MAGNA',GEOGCS['CGS_SIRGAS',DATUM['CGS_SIRGAS',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Transverse_Mercator'],PARAMETER['False_Easting',1000000.0],PARAMETER['False_Northing',1000000.0],PARAMETER['Central_Meridian',-74.077507917],PARAMETER['Scale_Factor',1.0],PARAMETER['Latitude_Of_Origin',4.596200417],UNIT['Meter',1.0]];-4623200 -9510300 10000;-100000 10000;-100000 10000;0.001;0.001;0.001;IsHighPrecision", "CZ")

    # Process: Select point from Julian day number
    arcpy.Select_analysis(R_EventLyr, R_ShapeFile, "\"Julian\" =" + i_str)

    # Process: IDW - Inverse Dinstance Weight Intepolation
    GRDayNFileName = "GRDay" + i_str + ".tif"
    GRDayN_tif = R_OutputFolder + GRDayNFileName
    arcpy.gp.Idw_sa(R_ShapeFile, "Var", GRDayN_tif, resGrids, "2", "VARIABLE 12", "")

    # Remove and create Temp folder
    shutil.rmtree(R_TempFolder) #Remove Temp folder
    os.mkdir(R_TempFolder) #Create empty Temp folder

    # Process: Show Raster created properties
    CY_Max = arcpy.GetRasterProperties_management(GRDayN_tif, "TOP", "")
    CY_MaxAux = float (CY_Max.getOutput(0))
    CY_Min = arcpy.GetRasterProperties_management(GRDayN_tif, "BOTTOM", "")
    CY_MinAux = float (CY_Min.getOutput(0))
    Y_Size = (CY_MaxAux - CY_MinAux) / 1000
    CX_Max = arcpy.GetRasterProperties_management(GRDayN_tif, "RIGHT", "")
    CX_MaxAux = float (CX_Max.getOutput(0))
    CX_Min = arcpy.GetRasterProperties_management(GRDayN_tif, "LEFT", "")
    CX_MinAux = float (CX_Min.getOutput(0))
    X_Size = (CX_MaxAux - CX_MinAux) / 1000
    Var_Max = arcpy.GetRasterProperties_management(GRDayN_tif, "MAXIMUM", "")
    Var_MaxAux = float (Var_Max.getOutput(0))
    print "R: File", GRDayNFileName, "- High(km):",Y_Size,"- Width(km):",X_Size,"- Maximum:",round(Var_MaxAux,4),"- successful..."
    if Var_MaxAux > maxPixelValue:
        maxPixelValue = Var_MaxAux
        dayMonthMax = i
    i += 1


# Grid color map using integer scale
i=1; maxPixelValueStr = str(maxPixelValue); vNumColorsStr = str(vNumColors);

print ""
print "-----------------------------------------------------------------------------------------"
print "R: Starting", numGrids_str, "Grids color scaled creation files"
while i <= numGrids:
    i_str = str(i)
    GRDayNFileName = "GRDay" + i_str + ".tif"
    GRDayN_tifSorce = R_OutputFolder + GRDayNFileName
    GRDayN_tifTarget = R_OutputFolderColorMap + GRDayNFileName
    algebraMapClc = "Int ((\""+GRDayN_tifSorce+"\" *"+vNumColorsStr+") / "+maxPixelValueStr+")"
    arcpy.gp.RasterCalculator_sa(algebraMapClc, GRDayN_tifTarget)
    print "R: File Color Map", GRDayNFileName,"successful..."
    arcpy.AddColormap_management(GRDayN_tifTarget, "", R_ColorMapFile)
    i += 1


vTimeEnd = time.time()
print ""
print "-----------------------------------------------------------------------------------------"
print "R: Grids created on                ", R_OutputFolder
print "R: Color Map Grids created on      ", R_OutputFolderColorMap
print "R: Maximun pixel value all grids)  ", round(maxPixelValue,4)
print "R: Day or Month with maximum value ", dayMonthMax
print "R: Process Acomplished              (dt = ", round(vTimeEnd - vTimeStart,1) , "secs or" , round((vTimeEnd - vTimeStart)/60,1) , "mins)"
print "-----------------------------------------------------------------------------------------"



# Command references
#os.system('pause') #Pause os system screen on Windows
#os.system('cls') #Clean screen on Windows
#raw_input("R: Press ENTER to start...") #User input for get a value or just for start process
#cadenaComila = "Hola \" " #Create a string using " inside string, use backslash bofore "
