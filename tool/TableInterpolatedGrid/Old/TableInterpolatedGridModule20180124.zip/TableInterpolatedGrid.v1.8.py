# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# TablaInterpolarPhyton_v1_0.py
# Created on: 2017-11-30 18:35:02.00000
# 
# Description: r.cfdtools@gmail.com Tested in ArcGis 10.5 with Python 2.7.12
# Using a R Weather CDMS App tables, create interpolate grids maps in a
# tiff format for everyday or every month. With the generate tiff maps
# user can make a video for to follow or study the weather parameter.
# Table format file input valid: dBase file .dbf or comma separated values .csv
# 
# REFERENCES:
#   http://www.mclibre.org/consultar/python/index.html
#   http://librosweb.es/libro/algoritmos_python/capitulo_12/excepciones.html
#   https://sourceforge.net/projects/dbfpy/files/dbfpy/2.3.1/
#   https://www.learnpython.org/es/String%20Formatting
#   https://www.rapidtables.com/web/color/RGB_Color.html
#   http://www.zonums.com/online/color_ramp/
# ---------------------------------------------------------------------------

# Import arcpy module
import arcpy
import os
import os.path
import shutil
import time
import warnings
warnings.filterwarnings("ignore")

# Local variables:
vOutputFolder = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\Out\\"
vOutputFolderColorMap = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\OutColorMap\\"
vTempFolder = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\Temp\\"
vTableBase = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\R_TableBaseExample2.dbf"
vShapeFile = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\Temp\\R_shapefile.shp"
vColorMapFile = "D:\\R_Weather\\Tools\\TablaIntepolarPhyton\\ColorMapStyle\\ColorMapArcGIS256_v12.clr"
vTimeStart = time.time()
vNumColor = 255 # Always use the total color less 1. Example: for 256 colors use 255 values (0 to 255)

# Welcome & Info screen
print ""
print "-----------------------------------------------------------------------------------------"
print "R: CREATE WEATHER PARAMETER GRID SETS USING dBASE TABLE"
print "R: by r.cfdtools@gmail.com Python: 2.7.12"
print "-----------------------------------------------------------------------------------------"
print "R: Alert - Close ARCGIS applications before start"
try:
    vNumGrid = int(input("R: Total Grids to create (12 for monthly or 365 for daily values) >> "))
except:
    vNumGrid = 1
    print "R: Alert - Number of grids do not enter, system create only 1 grid..."
try:
    vResGrid = int(input("R: Grid Resolution in meters (defaul 1000m) >> "))
except:
    vResGrid = 1000
    print "R: Alert - Grid resolution do not enter, system use 1000 meters by default..."
print "-----------------------------------------------------------------------------------------"
print ""


# Delete previous data Temp and Out folder created
try:
    shutil.rmtree(vOutputFolder) #Remove Out folder
except:
    print "R: Out folder doesn't exists"
os.mkdir(vOutputFolder) #Create empty Out folder
try:
    shutil.rmtree(vOutputFolderColorMap) #Remove Temp folder
except:
    print "R: Out Color Map folder doesn't exists"
os.mkdir(vOutputFolderColorMap) #Create empty Temp folder
try:
    shutil.rmtree(vTempFolder) #Remove Temp folder
except:
    print "R: Temp folder doesn't exists"
os.mkdir(vTempFolder) #Create empty Temp folder

# Grid builder section
vNumGridStr = str(vNumGrid)
vInc=1; vMaxPixelValue = -9999; vDayMonthMax = 0;
print "R: Starting", vNumGridStr, "Grids creation files..."
while vInc <= vNumGrid:
    vIncStr = str(vInc)

    # Process: Make XY Event Layer
    vEventLyr = "EventLyr" + vIncStr
    arcpy.MakeXYEventLayer_management(vTableBase, "CX", "CY", vEventLyr, "PROJCS['GAUSS_BTA_MAGNA',GEOGCS['CGS_SIRGAS',DATUM['CGS_SIRGAS',SPHEROID['GRS_1980',6378137.0,298.257222101]],PRIMEM['Greenwich',0.0],UNIT['Degree',0.0174532925199433]],PROJECTION['Transverse_Mercator'],PARAMETER['False_Easting',1000000.0],PARAMETER['False_Northing',1000000.0],PARAMETER['Central_Meridian',-74.077507917],PARAMETER['Scale_Factor',1.0],PARAMETER['Latitude_Of_Origin',4.596200417],UNIT['Meter',1.0]];-4623200 -9510300 10000;-100000 10000;-100000 10000;0.001;0.001;0.001;IsHighPrecision", "CZ")

    # Process: Select records from Julian day number
    arcpy.Select_analysis(vEventLyr, vShapeFile, "\"Julian\" =" + vIncStr)

    # Process: IDW - Inverse Dinstance Weight Intepolation
    vGRDayNFileName = "GRDay" + vIncStr.zfill(3) + ".tif"
    vGRDayNTif = vOutputFolder + vGRDayNFileName
    arcpy.gp.Idw_sa(vShapeFile, "Var", vGRDayNTif, vResGrid, "2", "VARIABLE 12", "")

    # Remove and create Temp folder
    shutil.rmtree(vTempFolder) #Remove Temp folder
    os.mkdir(vTempFolder) #Create empty Temp folder

    # Process: Show created raster properties
    vCYMax = arcpy.GetRasterProperties_management(vGRDayNTif, "TOP", "")
    vCYMaxAux = float (vCYMax.getOutput(0))
    vCYMin = arcpy.GetRasterProperties_management(vGRDayNTif, "BOTTOM", "")
    vCYMinAux = float (vCYMin.getOutput(0))
    vYSize = (vCYMaxAux - vCYMinAux) / 1000
    vCXMax = arcpy.GetRasterProperties_management(vGRDayNTif, "RIGHT", "")
    vCXMaxAux = float (vCXMax.getOutput(0))
    vCXMin = arcpy.GetRasterProperties_management(vGRDayNTif, "LEFT", "")
    vCXMinAux = float (vCXMin.getOutput(0))
    vXSize = (vCXMaxAux - vCXMinAux) / 1000
    vValMax = arcpy.GetRasterProperties_management(vGRDayNTif, "MAXIMUM", "")
    vValMaxAux = float (vValMax.getOutput(0))
    print "R: File", vGRDayNFileName, "- High(km):",vYSize,"- Width(km):",vXSize,"- Maximum:",round(vValMaxAux,4),"- successful..."
    if vValMaxAux > vMaxPixelValue:
        vMaxPixelValue = vValMaxAux
        vDayMonthMax = vInc
    vInc += 1


# Grid color map using integer scale
vInc=1; vMaxPixelValueStr = str(vMaxPixelValue); vNumColorStr = str(vNumColor);
print ""
print "-----------------------------------------------------------------------------------------"
print "R: Starting", vNumGridStr, "Grids color scaled creation files"
while vInc <= vNumGrid:
    vIncStr = str(vInc)
    vGRDayNFileName = "GRDay" + vIncStr.zfill(3) + ".tif"
    vGRDayNTifSorce = vOutputFolder + vGRDayNFileName
    vGRDayNTifTarget = vOutputFolderColorMap + vGRDayNFileName
    vAlgebraMapClc = "Int ((\""+vGRDayNTifSorce+"\" *"+vNumColorStr+") / "+vMaxPixelValueStr+")"
    arcpy.gp.RasterCalculator_sa(vAlgebraMapClc, vGRDayNTifTarget)
    print "R: File Color Map", vGRDayNFileName,"successful..."
    arcpy.AddColormap_management(vGRDayNTifTarget, "", vColorMapFile)
    vInc += 1

# Show final process information
vTimeEnd = time.time()
print ""
print "-----------------------------------------------------------------------------------------"
print "R: Grids created on                ", vOutputFolder
print "R: Color Map Grids created on      ", vOutputFolderColorMap
print "R: Maximun pixel value all grids)  ", round(vMaxPixelValue,4)
print "R: Day or Month with maximum value ", vDayMonthMax
print "R: Process Acomplished              (dt = ", round(vTimeEnd - vTimeStart,1) , "sec(s) or" , round((vTimeEnd - vTimeStart)/60,1) , "min(s))"
print "-----------------------------------------------------------------------------------------"


# Command references
#os.system('pause') #Pause os system screen on Windows
#os.system('cls') #Clean screen on Windows
#raw_input("R: Press ENTER to start...") #User input for get a value or just for start process
#cadenaComila = "Hola \" " #Create a string using " inside string, use backslash bofore "
