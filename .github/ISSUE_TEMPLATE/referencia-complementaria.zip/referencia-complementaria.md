---
name: Referencia complementaria
about: Proponga y envíe referencias complementarias para una o varias herramientas
  indicando sus enlaces y a cuál(es) herramienta(s) R.HydroTools aplica.
title: Referencia complementaria para la herramienta >> [indique el nombre aquí]
labels: documentation
assignees: ''

---

Para cada referencia indicar:
 - Nombre del libro, publicación o artículo:
 - Autor(es):
 - Edición:
 - ISBN:
 - Uso libre o comercial:
 - Páginas referenciadas:
 - Enlace en Internet:
 - Enlace de la herramienta R.HydroTools a la que aplica: (indicar enlace en GitHub, por ejemplo: _https://github.com/rcfdtools/R.HydroTools/tree/main/BordeLibreCanal_).
